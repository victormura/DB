create PROCEDURE EX_6 IS
   CURSOR c_muzeu is 
      select nume from muzee; 

   TYPE c_list IS TABLE of muzee.nume%type INDEX BY binary_integer; 
   lista_nume c_list; 
   suma number :=0; 
BEGIN 
   FOR n IN c_muzeu LOOP 
      suma := suma +1; 
      lista_nume(suma) := n.nume; 
      dbms_output.put_line('Muzeu('||suma||'):'||lista_nume(suma)); 
   END LOOP; 
dbms_output.put_line('Numarul de muzee din baza de date este:'||suma);
END;
/

